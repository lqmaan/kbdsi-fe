import { Component } from '@angular/core';

@Component({
  selector: 'app-popup-user',
  templateUrl: './popup-user.component.html',
  styleUrls: ['./popup-user.component.css']
})
export class PopupUserComponent {

}
